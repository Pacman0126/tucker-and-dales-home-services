SERVICE_PRICES = {
    "House Cleaning": 20.00,
    "Lawncare": 30.00,
    "Garage/Basement": 40.00,
}
SALES_TAX_RATE = 0.0825  # 8.25%
